import { base44 } from './base44Client';


export const Booking = base44.entities.Booking;

export const Review = base44.entities.Review;



// auth sdk:
export const User = base44.auth;